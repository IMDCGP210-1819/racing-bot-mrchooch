Track
-----
Copyright (C) 2005 Andrew Sumner (original track)
Copyright (C) 2005 Mayang Adninsome (modified images used for some textures)
Copyright (C) 2007 Andrew Sumner (fixed 3D errors, improved textures)

Copyleft: this work of art is free, you can redistribute
it and/or modify it according to terms of the Free Art license.
You will find a specimen of this license on the site
Copyleft Attitude http://artlibre.org as well as on other sites.
